﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using UploadFileApp.Models;

namespace UploadFileApp.Controllers
{
    public class FileUploadController : Controller
    {
        private readonly AppDbContext _context;
        public FileUploadController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
         [RequestSizeLimit(1000000)]
        public async Task<IActionResult> SingleFileUpload(IFormFile SingleFile)
        {
            //if (SingleFile != null && SingleFile.Length > 1000000)
            //{
            //    ModelState.AddModelError("","The file is too large");
            //}

            List<string> reqiredExt = new List<string> { ".jpg",".gif",".png" };
            string extension = Path.GetExtension(SingleFile.FileName).ToLower();
            if (!reqiredExt.Contains(extension))
            {
                ModelState.AddModelError("", "Invalid File Extension");
            }
            
                if (ModelState.IsValid)
               {
                if (SingleFile != null && SingleFile.Length > 0)
                {
                    var filepath = Path.Combine(Directory.GetCurrentDirectory(),"wwwroot/Uploads",SingleFile.FileName);

                    //using (var stream = System.IO.File.Create(filepath))
                    //{
                    //    await SingleFile.CopyToAsync(stream);

                    //    return View("UploadSuccess");
                    //}

                    using (var stream = new FileStream(filepath, FileMode.Create, FileAccess.Write))
                    {
                        await SingleFile.CopyToAsync(stream);
                    }

                    var model = new FileModel
                    {
                        FileName = SingleFile.FileName,
                        Length = SingleFile.Length,
                        ContentType = SingleFile.ContentType,
                        Data = ConverttoByteArray(filepath)

                    };

                    _context.Files.Add(model);
                    await _context.SaveChangesAsync();
                    return View("UploadSuccess");
                }
            }
            return View("Index");
        }

        private byte[] ConverttoByteArray(string filePath)
        {
            byte[] data;
            using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                using (BinaryReader reader = new BinaryReader(fs))
                {
                    data = reader.ReadBytes((int)fs.Length);
                }
            }
            return data;
        }

        [HttpGet]
        public async Task<IActionResult> GetImage(int Id)
        {
            FileModel row =await _context.Files.FirstOrDefaultAsync(x => x.Id == Id);
            
            return File(row.Data,row.ContentType);
        }

        public async Task<IActionResult> ShowImages()
        {
            var file = await _context.Files.ToListAsync();
            return View(file);
        }

        public IActionResult ShowImagesFromFolder()
        {
            var folder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Uploads");
            var files = Directory.EnumerateFiles(folder).Select(fn => Path.GetFileName(fn));

            return View(files); 

        }

        [HttpPost]
        public async Task<IActionResult> DeleteImage(int id)
        {
            var image = await _context.Files.FirstOrDefaultAsync(x => x.Id == id);
            var filepath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Uploads", image.FileName);
            if (System.IO.File.Exists(filepath))
            {
                System.IO.File.Delete(filepath);
            }

            _context.Files.Remove(image);
            await _context.SaveChangesAsync();

            return RedirectToAction("ShowImages");
        }
        [HttpGet]
        public IActionResult MultipleFileUpload()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> MultipleFileUpload(FileUploadModel model)
        {
            foreach (var file in model.MultipleFiles)
            {
                var fileName = file.FileName;
                var filePath = Path.Combine(Directory.GetCurrentDirectory(),"wwwroot/Uploads",fileName);

                using (var stream = new FileStream(filePath, FileMode.Create, FileAccess.Write))
                {
                    await file.CopyToAsync(stream);
                }
                var filemodel = new FileModel
                {
                    FileName = file.FileName,
                    Length = file.Length,
                    ContentType = file.ContentType,
                    Data = ConverttoByteArray(filePath)

                };

                _context.Files.Add(filemodel);
                await _context.SaveChangesAsync(); 

            }
            return View("UploadSuccess");
           
        }

    }
}
