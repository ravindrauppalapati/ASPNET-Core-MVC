﻿namespace UploadFileApp.Models
{
    public class FileUploadModel
    {
        public IEnumerable<IFormFile> MultipleFiles { get; set; }
    }
}
