﻿using System.ComponentModel.DataAnnotations;

namespace UploadFileApp.Models
{
    public class FileModel
    {
        [Key]
        public int Id { get; set; }
        public string FileName { get; set; }
        public long Length { get; set; }
        public string ContentType { get; set; }
        public byte[] Data { get; set; }


    }
}
