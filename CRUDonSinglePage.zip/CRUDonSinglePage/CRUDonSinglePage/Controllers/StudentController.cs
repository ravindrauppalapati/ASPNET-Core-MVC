﻿using CRUDonSinglePage.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUDonSinglePage.Controllers
{
    public class StudentController : Controller
    {
        private readonly AppDBContext _context;
        public StudentController(AppDBContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> getAll()
        {
            var students = await _context.Students.ToListAsync();
            if (students != null)
            {
                return Json(new { data = students });
            }

            return Json(new { success = false });
        }
        [HttpGet]
        public async Task<IActionResult> getById(int Id)
        {
            var student = await _context.Students.FindAsync(Id);
            if (student != null)
            {
                return Json(new { data = student });
            }

            return Json(new { success = false });
        }

        [HttpPost]
        public async Task<IActionResult> AddStudent([FromBody] Student student)
        {
            if (ModelState.IsValid)
            {
                _context.Students.Add(student);
                await _context.SaveChangesAsync();
                return Json(new { success = true });
            }
            return Json(new { success = false });
        }
        [HttpPost]
        public async Task<IActionResult> UpdateStudent([FromBody] Student student)
        {
            var stud = await _context.Students.FindAsync(student.Id);
            if (stud == null)
            {
                return Json(new { success = false });
            }
            if (ModelState.IsValid)
            {
                stud.Name = student.Name;
                stud.Address = student.Address;
                stud.Department = student.Department;
                await _context.SaveChangesAsync();

                return Json(new { success = true });
            }
            return Json(new { success = false });
        }
        [HttpPost]
        public async Task<IActionResult> DeleteStudent(int Id)
        {
            var stud = await _context.Students.FindAsync(Id);
            if (stud == null)
            {
                return Json(new { success = false });
            }
            _context.Students.Remove(stud);
            await _context.SaveChangesAsync();
            return Json(new { success = true });
        }
    }
}
