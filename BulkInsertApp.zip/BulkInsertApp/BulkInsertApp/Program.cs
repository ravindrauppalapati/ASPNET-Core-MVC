﻿using BulkInsertApp.Data;
using BulkInsertApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
namespace BulkInsertApp
{
    internal class Program
    {
        //static void Main(string[] args)
        //{
        //    #region Symmetric 
        //    //try
        //    //{
        //    //    List<Student> newStudents = new List<Student>()
        //    //    {
        //    //        new Student() { FirstName = "AAA", LastName = "A", Branch = "CSE" },
        //    //        new Student() { FirstName = "BBB", LastName = "B", Branch = "CSE" },
        //    //        new Student() { FirstName = "CCC", LastName = "C", Branch = "CSE" },
        //    //        new Student() { FirstName = "DDD", LastName = "D", Branch = "ETC" },
        //    //         new Student() { FirstName = "EEE", LastName = "E", Branch = "CSE" },
        //    //        new Student() { FirstName = "FFF", LastName = "F", Branch = "CSE" },
        //    //        new Student() { FirstName = "GGG", LastName = "G", Branch = "CSE" },
        //    //        new Student() { FirstName = "HHH", LastName = "H", Branch = "ETC" },
        //    //         new Student() { FirstName = "III", LastName = "I", Branch = "CSE" },
        //    //        new Student() { FirstName = "JJJ", LastName = "J", Branch = "CSE" }

        //    //    };
        //    //    using var context = new AppDBContext();
        //    //    context.BulkInsert(newStudents);
        //    //    Console.WriteLine("BulkInsert: Successfully inserted new students.");
        //    //    DisplayStudentsByBranch("CSE");
        //    //    Console.ReadKey();
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    Console.WriteLine($"BulkInsert Error: {ex.Message}");
        //    //}
        //    //==================================================================================

        //    //try
        //    //{
        //    //    Console.WriteLine("Starting BulkUpdate Operation...");
        //    //    string branchToUpdate = "CSE";
        //    //    BulkUpdateStudents(branchToUpdate);
        //    //    Console.WriteLine("BulkUpdate: Successfully updated student records.");
        //    //    DisplayStudentsByBranch(branchToUpdate);
        //    //    Console.ReadKey();
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    Console.WriteLine($"BulkUpdate Error: {ex.Message}");
        //    //}
        //    //===================================================================

        //    //try
        //    //{
        //    //    Console.WriteLine("Starting BulkDelete Operation...");
        //    //    string branchToDelete = "ETC";
        //    //    BulkDeleteStudents(branchToDelete);
        //    //    Console.WriteLine("BulkDelete: Successfully deleted student records."); 
        //    //    DisplayStudentsByBranch("ETC");
        //    //    Console.ReadKey();
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    Console.WriteLine($"BulkDelete Error: {ex.Message}");
        //    //}
        //    #endregion
        //}
        ////public static void BulkDeleteStudents(string branch)
        ////{
        ////    using var context = new AppDBContext();
        ////    var studentsToDelete = context.Students
        ////                                 .Where(std => std.Branch == branch)
        ////                                 .ToList();
        ////    context.BulkDelete(studentsToDelete);
        ////}
        ////public static void BulkUpdateStudents(string branch)
        ////{
        ////    using var context = new AppDBContext();
        ////    var studentsToUpdate = context.Students
        ////                                 .Where(std => std.Branch == branch)
        ////                                 .ToList();
        ////    foreach (var student in studentsToUpdate)
        ////    {
        ////        student.FirstName += " Updated";
        ////        student.LastName += " Updated";
        ////    }
        ////    context.BulkUpdate(studentsToUpdate);
        ////}

        ////public static void DisplayStudentsByBranch(string branch)
        ////{
        ////    using var context = new AppDBContext();
        ////    var studentsList = context.Students
        ////                              .AsNoTracking()
        ////                              .Where(std => std.Branch == branch)
        ////                              .ToList();
        ////    Console.WriteLine($"\nStudents in {branch} Branch:");
        ////    foreach (var student in studentsList)
        ////    {
        ////        Console.WriteLine($"\tStudent ID: {student.StudentId}, Name: {student.FirstName} {student.LastName}, Branch: {student.Branch}");
        ////    }
        ////}
        ///
        //static async Task Main(string[] args)
        //{
        //    Console.WriteLine("=== EF Core Asynchronous CRUD Operations with EF Extensions ===\n");

        //    try
        //    {
        //        using var context = new AppDBContext();

        //        await BulkInsertStudentsAsync(context);

        //        await DisplayStudentsByBranchAsync(context, "CSE");

        //        await BulkUpdateStudentsAsync(context, "CSE");

        //        await DisplayStudentsByBranchAsync(context, "CSE");

        //        await BulkDeleteStudentsAsync(context, "ETC");

        //        await DisplayStudentsByBranchAsync(context, "CSE");
        //        await DisplayStudentsByBranchAsync(context, "ETC");
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"\nAn unexpected error occurred: {ex.Message}");
        //    }
        //}

        //private static async Task BulkInsertStudentsAsync(AppDBContext context)
        //{
        //    Console.WriteLine("1. Starting Bulk Insert Operation...");

        //    List<Student> newStudents = new List<Student>()
        //    {
        //       new Student() { FirstName = "AAA", LastName = "A", Branch = "CSE" },
        //            new Student() { FirstName = "BBB", LastName = "B", Branch = "CSE" },
        //            new Student() { FirstName = "CCC", LastName = "C", Branch = "CSE" },
        //            new Student() { FirstName = "DDD", LastName = "D", Branch = "ETC" },
        //             new Student() { FirstName = "EEE", LastName = "E", Branch = "CSE" },
        //            new Student() { FirstName = "FFF", LastName = "F", Branch = "CSE" },
        //            new Student() { FirstName = "GGG", LastName = "G", Branch = "CSE" },
        //            new Student() { FirstName = "HHH", LastName = "H", Branch = "ETC" },
        //             new Student() { FirstName = "III", LastName = "I", Branch = "CSE" },
        //            new Student() { FirstName = "JJJ", LastName = "J", Branch = "CSE" }
        //    };

        //    try
        //    {
        //        await context.BulkInsertAsync(newStudents);

        //        Console.WriteLine("Bulk Insert: Successfully inserted new students.\n");
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"Bulk Insert Error: {ex.Message}\n");
        //    }
        //}

        //private static async Task DisplayStudentsByBranchAsync(AppDBContext context, string branch)
        //{
        //    Console.WriteLine($"2. Retrieving Students in '{branch}' Branch...\n");

        //    try
        //    {
        //        var studentsList = await context.Students
        //                                       .AsNoTracking()
        //                                       .Where(std => std.Branch == branch)
        //                                       .ToListAsync();

        //        if (studentsList.Any())
        //        {
        //            Console.WriteLine($"Students in '{branch}' Branch:");
        //            Console.WriteLine("-------------------------------------------------");
        //            foreach (var student in studentsList)
        //            {
        //                Console.WriteLine($"\tID: {student.StudentId}, Name: {student.FirstName} {student.LastName}, Branch: {student.Branch}");
        //            }
        //            Console.WriteLine();
        //        }
        //        else
        //        {
        //            Console.WriteLine($"No students found in '{branch}' Branch.\n");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"Read Error: {ex.Message}\n");
        //    }
        //}

        //private static async Task BulkUpdateStudentsAsync(AppDBContext context, string branch)
        //{
        //    Console.WriteLine("3. Starting Bulk Update Operation...");

        //    try
        //    {
        //        var studentsToUpdate = await context.Students
        //                                           .Where(std => std.Branch == branch)
        //                                           .ToListAsync();

        //        if (studentsToUpdate.Any())
        //        {
        //            foreach (var student in studentsToUpdate)
        //            {
        //                student.FirstName += " Updated";
        //                student.LastName += " Updated";
        //            }

        //            await context.BulkUpdateAsync(studentsToUpdate);

        //            Console.WriteLine("Bulk Update: Successfully updated student records.\n");
        //        }
        //        else
        //        {
        //            Console.WriteLine($"No students found in '{branch}' Branch to update.\n");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"Bulk Update Error: {ex.Message}\n");
        //    }
        //}

        //private static async Task BulkDeleteStudentsAsync(AppDBContext context, string branch)
        //{
        //    Console.WriteLine("4. Starting Bulk Delete Operation...");

        //    try
        //    {
        //        var studentsToDelete = await context.Students
        //                                           .Where(std => std.Branch == branch)
        //                                           .ToListAsync();

        //        if (studentsToDelete.Any())
        //        {
        //            await context.BulkDeleteAsync(studentsToDelete);

        //            Console.WriteLine($"Bulk Delete: Successfully deleted students from '{branch}' Branch.\n");
        //        }
        //        else
        //        {
        //            Console.WriteLine($"No students found in '{branch}' Branch to delete.\n");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"Bulk Delete Error: {ex.Message}\n");
        //    }
        //}

        //static async Task Main(string[] args)
        //{
        //    try
        //    {
        //        Console.WriteLine("Starting BulkMerge operation...");
        //        // Perform Bulk Merge operation
        //        await BulkMergeAsync();
        //        Console.WriteLine("BulkMerge operation completed.");
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"An error occurred: {ex.Message}");
        //    }
        //}
        //private static async Task BulkMergeAsync()
        //{
        //    using var context = new AppDBContext();
        //    List<Student> studentsToMerge = new List<Student>
        //    {
        //        new Student { StudentId = 1, FirstName = "John", LastName = "Doe Updated", Branch = "CSE" },

        //        new Student { FirstName = "Ramesh", LastName = "Sethy", Branch = "CSE" }
        //    };
        //    await context.BulkMergeAsync(studentsToMerge);
        //    await DisplayStudentsAsync();
        //}

        //private static async Task DisplayStudentsAsync()
        //{
        //    using var context = new AppDBContext();
        //    var students = await context.Students.ToListAsync();
        //    Console.WriteLine("Current Students in the database:");
        //    foreach (var student in students)
        //    {
        //        Console.WriteLine($"\tID: {student.StudentId}, Name: {student.FirstName} {student.LastName}, Branch: {student.Branch}");
        //    }
        //    Console.WriteLine();
        //}

        static async Task Main(string[] args)
        {
            try
            {
                Console.WriteLine("Starting BulkSaveChanges operation...");
                await BulkSaveChangesAsync();
                Console.WriteLine("BulkSaveChanges operation completed.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
        private static async Task BulkSaveChangesAsync()
        {
            using var context = new AppDBContext();
            var existingStudents = await context.Students.Where(s => s.Branch == "CSE").ToListAsync();
            foreach (var student in existingStudents)
            {
                student.FirstName += " Updated";
                student.LastName += " Updated";
            }
            context.Students.Add(new Student { FirstName = "New", LastName = "Student", Branch = "ETC" });
            var studentToDelete = await context.Students.Where(s => s.FirstName == "Sethy").FirstOrDefaultAsync();
            if (studentToDelete != null)
            {
                context.Students.Remove(studentToDelete);
            }
            await context.BulkSaveChangesAsync();
            await DisplayStudentsAsync();
        }
        private static async Task DisplayStudentsAsync()
        {
            using var context = new AppDBContext();
            var students = await context.Students.ToListAsync();
            Console.WriteLine("Current Students in the database:");
            foreach (var student in students)
            {
                Console.WriteLine($"ID: {student.StudentId}, Name: {student.FirstName} {student.LastName}, Branch: {student.Branch}");
            }
            Console.WriteLine();
        }
    }
}
 

