﻿using Batch_Processing_Job_Scheduler.Data;
using Batch_Processing_Job_Scheduler.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch_Processing_Job_Scheduler.Services
{
    public class JobService
    {
        public async Task<Job> CreateNewJobAsync()
        {
            using var context = new EFCoreDbContext();
            var job = new Job
            {
                StartTime = DateTime.Now,
                Status = "Started",
                SuccessfulPayments = 0, // Initializing
                FailedPayments = 0,     // Initializing
                TotalPayments = 0,
                BatchSize = 0,
                TotalBatches = 0
            };
            context.Jobs.Add(job);
            await context.SaveChangesAsync();
            Logger.Log($"Job {job.JobId} started at {job.StartTime}.");
            return job;
        }
        public async Task CompleteJobAsync(Job job)
        {
            using var context = new EFCoreDbContext();
            job.EndTime = DateTime.Now;
            if (job.FailedPayments > 0 && job.SuccessfulPayments > 0)
            {
                job.Status = "Partially Completed";
            }
            else if (job.FailedPayments == 0)
            {
                job.Status = "Completed";
            }
            else
            {
                job.Status = "Failed";
            }
            context.Entry(job).State = EntityState.Modified;
            await context.SaveChangesAsync();
            Logger.Log($"Job {job.JobId} completed at {job.EndTime}. Successful payments: {job.SuccessfulPayments}, Failed payments: {job.FailedPayments}.");
        }


        public async Task LogJobDetailsAsync(Job job, Payment payment, string previousStatus, bool isSuccess)
        {
            using var context = new EFCoreDbContext();
            var jobDetail = new JobDetail
            {
                JobId = job.JobId,
                PaymentId = payment.PaymentId,
                PreviousStatus = previousStatus,
                NewStatus = payment.Status,
                IsSuccess = isSuccess
            };
            context.JobDetails.Add(jobDetail);
            if (isSuccess)
            {
                job.SuccessfulPayments++;
            }
            else
            {
                job.FailedPayments++;
            }
            await context.SaveChangesAsync();
            Logger.Log($"Payment {payment.PaymentId}: Status updated from {previousStatus} to {payment.Status}. Success: {isSuccess}.");
        }
    }
}
