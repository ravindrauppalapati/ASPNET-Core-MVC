﻿using Batch_Processing_Job_Scheduler.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch_Processing_Job_Scheduler.Services
{
    public class PaymentGatewayService
    {
        private readonly Random _random = new Random();
        private readonly List<string> _statuses = new List<string> { "Pending", "Completed", "Failed", "Cancelled" };
        public async Task<string> GetUpdatedPaymentStatusAsync(Payment payment)
        {
            try
            {
                if (_random.Next(1, 10) > 8)
                {
                    throw new Exception("Payment gateway is temporarily unavailable.");
                }
                await Task.Delay(200);
                return payment.Status == "Pending" ? _statuses[_random.Next(_statuses.Count)] : payment.Status;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error accessing payment gateway for Payment ID {payment.PaymentId}: {ex.Message}");
            }
        }
    }
}
