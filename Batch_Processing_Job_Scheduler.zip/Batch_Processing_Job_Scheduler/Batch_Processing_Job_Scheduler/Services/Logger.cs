﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch_Processing_Job_Scheduler.Services
{
    public class Logger
    {
        private static string logFilePath;
        static Logger()
        {
            string folderPath = @"D:\Logs";
            Directory.CreateDirectory(folderPath);
            string currentDate = DateTime.Now.ToString("yyyyMMdd");
            string fileName = $"Log_{currentDate}.txt";
            logFilePath = Path.Combine(folderPath, fileName);
        }
        public static void Log(string message)
        {
            try
            {
                var logMessage = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}";
                File.AppendAllText(logFilePath, logMessage + Environment.NewLine);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Logging failed: {ex.Message}");
            }
        }
    }
}
