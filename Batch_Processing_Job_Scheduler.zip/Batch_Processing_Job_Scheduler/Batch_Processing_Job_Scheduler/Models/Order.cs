﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch_Processing_Job_Scheduler.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        public string Status { get; set; } // Status of the order (Pending, Processing, Completed, Cancelled)
        public int CustomerId { get; set; }
        public Customer Customer { get; set; }
        public Payment Payment { get; set; }
    }
}
