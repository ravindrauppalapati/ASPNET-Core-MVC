﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch_Processing_Job_Scheduler.Models
{
    public class Job
    {
        public int JobId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string Status { get; set; }
        public int TotalPayments { get; set; }
        public int SuccessfulPayments { get; set; }
        public int FailedPayments { get; set; }
        public int BatchSize { get; set; }
        public int TotalBatches { get; set; }
        public ICollection<JobDetail> JobDetails { get; set; }
    }
}
