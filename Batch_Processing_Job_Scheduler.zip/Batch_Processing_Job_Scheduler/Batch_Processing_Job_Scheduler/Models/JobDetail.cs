﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch_Processing_Job_Scheduler.Models
{
    public class JobDetail
    {
        public int JobDetailId { get; set; }
        public int JobId { get; set; }
        public int PaymentId { get; set; }
        public string PreviousStatus { get; set; }
        public string NewStatus { get; set; }
        public bool IsSuccess { get; set; }
        public Job Job { get; set; }
        public Payment Payment { get; set; }
    }
}
