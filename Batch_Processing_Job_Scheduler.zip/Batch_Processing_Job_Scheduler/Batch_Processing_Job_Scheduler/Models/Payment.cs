﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch_Processing_Job_Scheduler.Models
{
    public class Payment
    {
        public int PaymentId { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }
        public string Currency { get; set; }
        public string Status { get; set; } // Payment status: Pending, Completed, Failed, Cancelled
        public string TransactionId { get; set; }
        public string? FailureReason { get; set; }
        public int OrderId { get; set; }
        public Order Order { get; set; }
    }
}
