﻿using ConcurrencyCheckApp.Data;
using ConcurrencyCheckApp.Models;

namespace ConcurrencyCheckApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Main Method Started");
                Thread t1 = new Thread(Method1);
                Thread t2 = new Thread(Method2);
                t1.Start();
                t2.Start();
                t1.Join();
                t2.Join();
                Console.WriteLine("Main Method Completed");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}"); ;
            }
        }
        public static void Method1()
        {
            using AppDBContext context = new AppDBContext();
            var studentId1 = context.Students.Find(1);
            Thread.Sleep(TimeSpan.FromSeconds(2));
            if (studentId1 != null)
            {
                studentId1.Name = studentId1.Name + "Method1";
                studentId1.Branch = studentId1.Branch + "Method1";
                context.SaveChanges();
                Console.WriteLine("Student Updated by Method1");
            }
        }
        public static void Method2()
        {
            using AppDBContext context = new AppDBContext();
            var studentId1 = context.Students.Find(1);
            Thread.Sleep(TimeSpan.FromSeconds(2));
            if (studentId1 != null)
            {
                studentId1.Name = studentId1.Name + " Method2";
                studentId1.Branch = studentId1.Branch + " Method2";
                context.SaveChanges();
                Console.WriteLine("Student Updated by Method2");
            }
        }
    }
}
