﻿using EFCoreTransaction.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Data.Common;
using System.Transactions;

namespace EFCoreTransaction
{
    internal class Program
    {
        public static DbTransaction BeginDatabaseTransaction(AppDbContext context)
        {
            var connection = context.Database.GetDbConnection();
            if (connection.State != ConnectionState.Open)
            {
                connection.Open();
            }
            return connection.BeginTransaction();
        }

        public static void UseExistingTransaction(AppDbContext context, DbTransaction transaction)
        {
            context.Database.UseTransaction(transaction);
            try
            {
                var stud1 = new Student() { FirstName = "Lucky", LastName = "Honey" };
                context.Students.Add(stud1);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                context.Database.UseTransaction(null);
            }
        }
      public static void Main(string[] args)
        {
            try
            {
                // Automatic

                //using (var context = new AppDbContext())
                //{
                //    var stud1 = new Student() { FirstName = "Ravindra", LastName = "babu" };
                //    var stud2 = new Student() { FirstName = "Narendra", LastName = "Kumar" };
                //    context.Students.Add(stud1);
                //    context.SaveChanges();
                //    context.Students.Add(stud2);
                //    context.SaveChanges();

                //    Console.WriteLine("Entities are Added");
                //    Console.ReadLine();
                //}

                //=============================================================

                // Manual 

                //    using (var context = new AppDbContext())
                //    {
                //        using (var transaction = context.Database.BeginTransaction())
                //        {
                //            try
                //            {
                //                var stud1 = new Student() { FirstName = "raj", LastName = "babu" };
                //                var stud2 = new Student() { FirstName = "sai", LastName = "Kumar" };
                //                context.Students.Add(stud1);
                //                context.SaveChanges();
                //                context.Students.Add(stud2);
                //                context.SaveChanges();
                //                transaction.Commit();
                //                Console.WriteLine("Entities are Added");
                //            } 
                //            catch (Exception ex)
                //            {
                //                transaction.Rollback();
                //                Console.WriteLine(ex.Message);
                //                throw;
                //            }


                //        }
                //    }

                //==================================================  
                //Async

                //using (var context = new AppDbContext())
                //{
                //  await  using (var transaction = await context.Database.BeginTransactionAsync())
                //    {
                //        try
                //        {
                //            var stud1 = new Student() { FirstName = "raj", LastName = "babu" };
                //            var stud2 = new Student() { FirstName = "sai", LastName = "Kumar" };
                //            context.Students.Add(stud1);
                //           await context.SaveChangesAsync();
                //            context.Students.Add(stud2);
                //            await context.SaveChangesAsync();
                //            await transaction.CommitAsync();
                //            Console.WriteLine("Entities are Added");
                //        }
                //        catch (Exception ex)
                //        {
                //            await transaction.RollbackAsync();
                //            Console.WriteLine(ex.Message);
                //            throw;
                //        }
                //    }
                //}

                //==============================================================
                //Distributed

                //var options = new TransactionOptions
                //{
                //    IsolationLevel = IsolationLevel.ReadCommitted,
                //    Timeout = TransactionManager.DefaultTimeout
                //};
                //using (var scope = new TransactionScope(TransactionScopeOption.Required, options))
                //{
                //    try
                //    {
                //        using (var context1 = new AppDbContext())
                //        {
                //            var stud1 = new Student() { FirstName = "AAA", LastName = "babu" };
                //            context1.Students.Add(stud1);
                //            context1.SaveChanges();
                //        }
                //        using (var context2 = new AppDbContext())
                //        {
                //            var stud2 = new Student() { FirstName = "BBB", LastName = "babu" };
                //            context2.Students.Add(stud2);
                //            context2.SaveChanges();
                //        }

                //        scope.Complete();
                //        Console.WriteLine("Entities are Added");
                //    }
                //    catch (Exception ex)
                //    {
                //    }
                //}
                //==============================================================
                //Existing
                using (var context = new AppDbContext())
                {
                    using (var transaction = BeginDatabaseTransaction(context))
                    {
                        try
                        {
                            var stud1 = new Student() { FirstName = "AAA", LastName = "AAA" };
                            context.Students.Add(stud1); 
                            UseExistingTransaction(context, transaction);
                            transaction.Commit();
                            Console.WriteLine("Entities are Added");
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }


                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
 
        }
    }
}
