﻿using Microsoft.AspNetCore.Mvc;

namespace CustomRouteConstraints.Controllers
{
    public class StudentController : Controller
    {
        public string Index()
        {
            return $"Index Method";
        }
        public string Details(string id)
        {
            return $"Details {id} Method";
        }
    }
}
