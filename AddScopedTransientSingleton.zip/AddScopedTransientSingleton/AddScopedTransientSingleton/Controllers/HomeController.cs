using AddScopedTransientSingleton.Models;
using AddScopedTransientSingleton.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace AddScopedTransientSingleton.Controllers
{
    public class HomeController : Controller
    {
        private readonly IStudentRepository _studentRepository;
        private readonly AnotherService _anotherService;
        private readonly NewServiceForTest _newService;

        public HomeController(IStudentRepository studentRepository, AnotherService anotherService , NewServiceForTest newServiceForTest)
        {
            _anotherService = anotherService;
            _studentRepository = studentRepository;
            _newService = newServiceForTest;
        }

        public JsonResult Index()
        {
           List<Student> students= _studentRepository.getAllStudents();
            _anotherService.Method();
            _newService.MethodTest();
            return Json(students);
        }

        public JsonResult getStudentByID(int id)
        {
            Student stud = _studentRepository.getStudentById(id);
            _anotherService.Method();
            _newService.MethodTest();
            return Json(stud);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
