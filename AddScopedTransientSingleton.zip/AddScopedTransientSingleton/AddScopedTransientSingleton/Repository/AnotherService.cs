﻿namespace AddScopedTransientSingleton.Repository
{
    public class AnotherService
    {
        private readonly IStudentRepository _studentRepository;
        public AnotherService(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }

        public void Method()
        {
        }
    }
}
