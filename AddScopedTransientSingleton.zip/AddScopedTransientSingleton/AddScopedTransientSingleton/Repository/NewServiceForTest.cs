﻿namespace AddScopedTransientSingleton.Repository
{
    public class NewServiceForTest
    {
        private readonly IStudentRepository _studentRepository;
        public NewServiceForTest(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }

        public void MethodTest()
        { }
    }
}
