﻿using AddScopedTransientSingleton.Models;

namespace AddScopedTransientSingleton.Repository
{
    public class StudentRepository : IStudentRepository
    {
        public StudentRepository()
        {
            string filepath = @"D:\Log.txt";

            string content = $"Object created for Student Repo : @{DateTime.Now.ToString()}";

            using (StreamWriter writer = new StreamWriter(filepath, true))
            {
                writer.WriteLine(content);
            }
        }

        public List<Student> DataSource()
        {
            return new List<Student>
            {
                new Student(){ StudentId=1,Name="AAA",Branch="CSE",Section="A",Gender="Male"},
                new Student(){ StudentId=1,Name="BBB",Branch="EEE",Section="B",Gender="FeMale"},
                new Student(){ StudentId=1,Name="CCC",Branch="ECE",Section="A",Gender="Male"},
                new Student(){ StudentId=1,Name="DDD",Branch="Mech",Section="B",Gender="FeMale"},
                new Student(){ StudentId=1,Name="EEE",Branch="CSE",Section="A",Gender="Male"},
                new Student(){ StudentId=1,Name="FFF",Branch="CSE",Section="B",Gender="Male"},
            };
        }
        public List<Student> getAllStudents()
        {
             return DataSource().ToList();
        }

        public Student getStudentById(int id)
        {
            return DataSource().FirstOrDefault(s => s.StudentId == id) ?? new Student();
        }
    }
}
