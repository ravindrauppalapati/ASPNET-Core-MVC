﻿using AddScopedTransientSingleton.Models;

namespace AddScopedTransientSingleton.Repository
{
    public interface IStudentRepository
    {
        Student getStudentById(int id);
        List<Student> getAllStudents();
    }
}
