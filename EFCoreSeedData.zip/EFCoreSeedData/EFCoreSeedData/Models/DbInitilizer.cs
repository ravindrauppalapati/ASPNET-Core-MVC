﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreSeedData.Models
{
    internal static class DbInitializer
    {
        public static void Initialize(AppDBContext context)
        {
            context.Database.EnsureCreated(); 

            if (context.Countries.Any() || context.states.Any() || context.cities.Any())
            { 
                return;
            }
            else
            { 
               // IList<Country> countries = new List<Country>();
                Country IND = new() { CountryName = "INDIA", CountryCode = "IND" };
                Country US = new() { CountryName = "AMERICA", CountryCode = "US" };
                //countries.Add(IND);
                //countries.Add(US);
                context.Countries.AddRange(IND, US);
                 
              //  IList<State> states = new List<State>();
                State Odisha = new() { StateName = "ODISHA", CountryId = IND.CountryId };
                State Andhra = new() { StateName = "ANDHRA", CountryId = IND.CountryId };
                //states.Add(Odisha);
                //states.Add(Andhra);
                context.states.AddRange(Odisha, Andhra);
               
                //IList<City> cities = new List<City>();
                City gun = new() {  CityName = "GUNTUR", StateId = Odisha.StateId };
                City viz = new() {  CityName = "VIZAG", StateId = Odisha.StateId };
                //cities.Add(gun);
                //cities.Add(viz);
                context.cities.AddRange(gun, viz);
               
            }
            context.SaveChanges();
        }
    }
}
    
 
