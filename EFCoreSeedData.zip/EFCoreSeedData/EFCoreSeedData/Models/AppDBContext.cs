﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreSeedData.Models
{
    internal class AppDBContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=.\MSSQLSERVER1;Initial Catalog=EFCoreSeedDataDB;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        //      modelBuilder.Entity<Country>().HasData(
        //          new() { CountryId =1,CountryName ="INDIA",CountryCode="IND"},
        //          new() { CountryId=2,CountryName ="America",CountryCode="US"} 
        //        );
        //    modelBuilder.Entity<State>().HasData(
        //          new() { StateId = 1, StateName = "ODISHA", CountryId = 1,},
        //          new() { StateId = 2, StateName = "ANDHRA", CountryId = 1}
        //        );

        //    modelBuilder.Entity<City>().HasData(
        //         new() {  CityId = 1, CityName = "Guntur", StateId = 2 },
        //         new() { CityId = 2, CityName = "Vizag", StateId = 2 }
        //       );

        }

        public DbSet<Country> Countries { get; set; }
        public DbSet<State> states { get; set; }
        public DbSet<City> cities { get; set; }
    }
}
