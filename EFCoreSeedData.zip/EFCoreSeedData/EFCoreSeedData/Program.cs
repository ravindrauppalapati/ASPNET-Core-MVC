﻿using EFCoreSeedData.Models;

namespace EFCoreSeedData
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                using (var context = new AppDBContext())
                {
                    DbInitializer.Initialize(context);
                }

                Console.WriteLine("DB Created");
            }
            catch (Exception ex)
            {
            }
        }
    }
}
