﻿using LinktoEntities.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace LinktoEntities
{
    internal class Program
    {
        static void Main(string[] args)
        {    //================== Search ====================================
             //try
             //{
             //    using (var dbcontext = new EFCoreDbContext())
             //    {
             //        string firstName = "Alice";
             //        var SearchQS = (from student  in dbcontext.Students
             //                        where student.FirstName == firstName
             //                        select student).ToList();

            //        var searchMS= dbcontext.Students.Where(x => x.FirstName == firstName).ToList();
            //        if (SearchQS.Any())
            //        {
            //            foreach (var item in SearchQS)
            //            {
            //                Console.WriteLine($"FirstName : {item.FirstName},LastName: {item.LastName}.Email : {item.Email}");
            //            }
            //        }
            //    }
            //}

            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.ToString());
            //}

            //=================================  Filter =================================
            //try
            //{
            //    using (var context = new EFCoreDbContext())
            //    {
            //        string branchName = "Computer Science Engineering";
            //        string gender = "Female";

            //        var filteredStudentsQS = (from student in context.Students
            //                                 .Include(s => s.Branch)
            //                                  where student.Branch.BranchName == branchName && student.Gender == gender
            //                                  select student).ToList();

            //        var filteredStudents = context.Students
            //                                      .Include(s => s.Branch)
            //                                      .Where(s => s.Branch.BranchName == branchName && s.Gender == gender)
            //                                      .ToList();

            //        if (filteredStudentsQS.Any())
            //        {
            //            foreach (var student in filteredStudentsQS)
            //            {
            //                Console.WriteLine($"Student Found: {student.FirstName} {student.LastName}, Branch: {student.Branch.BranchName}, Gender: {student.Gender}");
            //            }
            //        }
            //        else
            //        {
            //            Console.WriteLine("No students found matching the given criteria.");
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"An error occurred: {ex.Message}");
            //}
            //========================Sorting==============================
            //try
            //{
            //    using (var context = new EFCoreDbContext())
            //    {
            //        var sortedStudentsQuerySyntax = (from student in context.Students
            //                                         orderby student.Gender ascending, student.EnrollmentDate descending
            //                                         select student).ToList();

            //        var sortedStudentsMethodSyntax = context.Students
            //                                                .OrderBy(s => s.Gender)
            //                                                .ThenByDescending(s => s.EnrollmentDate)
            //                                                .ToList();

            //        if (sortedStudentsQuerySyntax.Any())
            //        {
            //            foreach (var student in sortedStudentsQuerySyntax)
            //            {
            //                Console.WriteLine($"Student: {student.LastName} {student.FirstName}, Gender: {student.Gender}, Enrollment Date: {student.EnrollmentDate.ToShortDateString()}");
            //            }
            //        }
            //        else
            //        {
            //            Console.WriteLine("No students found.");
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"An error occurred: {ex.Message}");
            //}
            //=========================================Grouping===========================

            //try
            //{
            //    using (var context = new EFCoreDbContext())
            //    {
            //        var groupedStudentsQuerySyntax = (from student in context.Students
            //                                         .Include(s => s.Branch)
            //                                          group student by student.Branch.BranchName into studentGroup
            //                                          select new
            //                                          {
            //                                              BranchName = studentGroup.Key,

            //                                              StudentCount = studentGroup.Count()
            //                                          }).ToList();
            //        // Grouping students by their Branch using Method Syntax
            //        var groupedStudentsMethodSyntax = context.Students
            //                                                .Include(s => s.Branch)
            //                                               .GroupBy(s => s.Branch.BranchName)
            //                                               .Select(g => new
            //                                               {
            //                                                   BranchName = g.Key,
            //                                                   StudentCount = g.Count()
            //                                               })
            //                                                .ToList();

            //        if (groupedStudentsQuerySyntax.Any())
            //        {
            //            foreach (var group in groupedStudentsQuerySyntax)
            //            {
            //                Console.WriteLine($"\nBranch: {group.BranchName}, Number of Students: {group.StudentCount}");
            //            }
            //        }
            //        else
            //        {
            //            Console.WriteLine("No students found.");
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"An error occurred: {ex.Message}");
            //}
            //====================== Joins ================================
            //try
            //{
            //    using (var context = new EFCoreDbContext())
            //    {
            //        var studentsWithBranchesQuerySyntax = (from student in context.Students
            //                                               join branch in context.Branches
            //                                               on student.Branch.BranchId equals branch.BranchId
            //                                               select new
            //                                               {
            //                                                   student.FirstName,
            //                                                   student.LastName,
            //                                                   student.Email,
            //                                                   student.EnrollmentDate,
            //                                                   branch.BranchName
            //                                               }).ToList();

            //        // Joining Students and Branches using Method Syntax (LINQ method chaining)
            //        var studentsWithBranchesMethodSyntax = context.Students
            //                                                      .Join(context.Branches,
            //                                                            student => student.Branch.BranchId,
            //                                                            branch => branch.BranchId,
            //                                                            (student, branch) => new
            //                                                            {
            //                                                                student.FirstName,
            //                                                                student.LastName,
            //                                                                student.Email,
            //                                                                student.EnrollmentDate,
            //                                                                branch.BranchName
            //                                                            })
            //                                                      .ToList();

            //        if (studentsWithBranchesQuerySyntax.Any())
            //        {
            //            foreach (var item in studentsWithBranchesQuerySyntax)
            //            {
            //                Console.WriteLine($"Student: {item.FirstName} {item.LastName}, Email: {item.Email}, Enrollment Date: {item.EnrollmentDate.ToShortDateString()}, Branch: {item.BranchName}");
            //            }
            //        }
            //        else
            //        {
            //            Console.WriteLine("No students found.");
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"An error occurred: {ex.Message}");
            //}
            //===============================================================================
            try
            {
                using (var context = new EFCoreDbContext())
                {
                    Console.WriteLine("==============Branch Wise Report==============");
                    // LINQ Query Syntax:

                    var branchDetailsQuerySyntax = (from branch in context.Branches

                                                    join student in context.Students on branch.BranchId equals student.Branch.BranchId
                                                    group student by new { branch.BranchId, branch.BranchName } into branchGroup
                                                    select new
                                                    {
                                                        BranchName = branchGroup.Key.BranchName,
                                                        Students = branchGroup.ToList()
                                                    })
                                                    .AsEnumerable()
                                                    .Select(branch => new
                                                    {
                                                        BranchName = branch.BranchName,
                                                        StudentCount = branch.Students.Count(),
                                                        AverageEnrollmentDate = branch.Students.Average(s => s.EnrollmentDate.Ticks),
                                                        Students = branch.Students.OrderBy(s => s.LastName).ThenBy(s => s.FirstName).ToList()
                                                    });

                    var branchDetailsMethodSyntax = context.Branches
                                                           .Join(context.Students,
                                                                 branch => branch.BranchId,
                                                                 student => student.Branch.BranchId,
                                                                 (branch, student) => new { branch, student })
                                                           .GroupBy(bs => new { bs.branch.BranchId, bs.branch.BranchName })
                                                           .AsEnumerable()
                                                           .Select(g => new
                                                           {
                                                               BranchName = g.Key.BranchName,
                                                               StudentCount = g.Count(),
                                                               AverageEnrollmentDate = g.Average(bs => bs.student.EnrollmentDate.Ticks),
                                                               Students = g.Select(bs => bs.student).OrderBy(s => s.LastName).ThenBy(s => s.FirstName).ToList()
                                                           })
                                                           .ToList();

                    if (branchDetailsQuerySyntax.Any())
                    {
                        foreach (var branch in branchDetailsQuerySyntax)
                        {
                            Console.WriteLine($"\nBranch: {branch.BranchName}");
                            Console.WriteLine($"Number of Students: {branch.StudentCount}");
                            Console.WriteLine($"Average Enrollment Date: {new DateTime(Convert.ToInt64(branch.AverageEnrollmentDate)).ToShortDateString()}");

                            foreach (var student in branch.Students)
                            {
                                Console.WriteLine($"    Student: {student.LastName}, {student.FirstName} - Enrollment Date: {student.EnrollmentDate.ToShortDateString()}, Email: {student.Email}");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("No branch details found.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
    }
}
