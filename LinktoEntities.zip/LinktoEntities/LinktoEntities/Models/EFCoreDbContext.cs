﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinktoEntities.Models
{
    internal class EFCoreDbContext :DbContext
    {
        //public EFCoreDbContext(DbContextOptions<EFCoreDbContext> opts) : base(opts) { }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        { 
            optionsBuilder.UseSqlServer(@"Data Source=.\MSSQLSERVER1;Initial Catalog=LinkToEntityDB;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
        }

        public DbSet<Student> Students { get; set; } 
        public DbSet<Branch> Branches { get; set; }
    }
}
