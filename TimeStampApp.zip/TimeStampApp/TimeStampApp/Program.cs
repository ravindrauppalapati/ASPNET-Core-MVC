﻿using Microsoft.EntityFrameworkCore;
using TimeStampApp.Data;
using TimeStampApp.Models;

namespace TimeStampApp
{
    internal class Program
    {
        private static int userAQuantity = 3;
        private static int userBQuantity = 7;
        private static bool userAOperationSuccess = false;
        private static bool userBOperationSuccess = false;
        static void Main(string[] args)
        {
            try
            {
                int initialStock = 0;
                using (var context = new AppDbContext())
                {
                    var initialProduct = context.Products.Find(1);
                    initialStock = initialProduct?.StockQuantity ?? 0;
                    Console.WriteLine($"Initial stock in database: {initialStock}");
                }
                Thread t1 = new Thread(Method1);
                Thread t2 = new Thread(Method2);
                Console.WriteLine("Booking started by User A and User B");
                t1.Start();
                t2.Start();
                t1.Join();
                t2.Join();
                using (var context = new AppDbContext())
                {
                    var finalProduct = context.Products.Find(1);
                    int expectedFinalStock = initialStock;
                    if (userAOperationSuccess)
                    {
                        expectedFinalStock -= userAQuantity;
                    }
                    if (userBOperationSuccess)
                    {
                        expectedFinalStock -= userBQuantity;
                    }
                    Console.WriteLine($"Expected final stock (Initial stock - successful User A booking - successful User B booking): {expectedFinalStock}");
                    Console.WriteLine($"Final stock in database: {finalProduct?.StockQuantity}");
                    if (finalProduct != null && finalProduct.StockQuantity == expectedFinalStock)
                    {
                        Console.WriteLine("Final stock is correct.");
                    }
                    else
                    {
                        Console.WriteLine("Final stock is incorrect. There may be a concurrency issue.");
                    }
                }
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }


        // User A | Transaction 1 | Booking 3 items
        public static void Method1()
        {
            try
            {
                using AppDbContext context = new AppDbContext();
                var product1 = context.Products.Find(1);
                Thread.Sleep(TimeSpan.FromSeconds(2));
                if (product1 != null)
                {
                    product1.StockQuantity -= userAQuantity;
                    context.SaveChanges();
                    Console.WriteLine($"User A booked {userAQuantity} items. Updated stock after User A: {product1.StockQuantity}");
                    userAOperationSuccess = true;
                }
            }
            catch (DbUpdateException ex)
            {
                Console.WriteLine($"User A Error: {ex.InnerException?.Message ?? ex.Message}");
                userAOperationSuccess = false;
            }
        }
        // User B | Transaction 2 | Booking 7 items
        public static void Method2()
        {
            try
            {
                using AppDbContext context = new AppDbContext();
                var product1 = context.Products.Find(1);
                Thread.Sleep(TimeSpan.FromSeconds(5));
                if (product1 != null)
                {
                    product1.StockQuantity -= userBQuantity;
                    context.SaveChanges();
                    Console.WriteLine($"User B booked {userBQuantity} items. Updated stock after User B: {product1.StockQuantity}");
                    userBOperationSuccess = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"User B Error: {ex.InnerException?.Message ?? ex.Message}");
                userBOperationSuccess = false;
            }
        }


    }
}
