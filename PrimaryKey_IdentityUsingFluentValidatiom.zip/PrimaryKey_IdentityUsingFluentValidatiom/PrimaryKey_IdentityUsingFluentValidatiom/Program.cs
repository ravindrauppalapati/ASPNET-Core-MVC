﻿using PrimaryKey_IdentityUsingFluentValidatiom.Data;
using PrimaryKey_IdentityUsingFluentValidatiom.Models;
using Microsoft.EntityFrameworkCore;
namespace PrimaryKey_IdentityUsingFluentValidatiom
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //try
            //{
            //    using (var context = new AppDbContext())
            //    {
            //        Console.WriteLine("Inserting log data...");
            //        var log1 = new Log
            //        {
            //            LogMessage = "First log entry",
            //            LogDate = DateTime.Now
            //        };
            //        var log2 = new Log
            //        {
            //            LogMessage = "Second log entry",
            //            LogDate = DateTime.Now.AddMinutes(5)
            //        };
            //        context.Database.ExecuteSqlRaw(
            //            "INSERT INTO Logs (LogMessage, LogDate) VALUES ({0}, {1})", log1.LogMessage, log1.LogDate);
            //        context.Database.ExecuteSqlRaw(
            //            "INSERT INTO Logs (LogMessage, LogDate) VALUES ({0}, {1})", log2.LogMessage, log2.LogDate);
            //        Console.WriteLine("Log entries added successfully!");
            //        Console.WriteLine("Fetching log data...");
            //        var logs = context.Logs.AsNoTracking().ToList();
            //        foreach (var log in logs)
            //        {
            //            Console.WriteLine($"Log: {log.LogMessage}, Date: {log.LogDate}");
            //        }
            //        Console.WriteLine("Log data fetched successfully!");
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"Error: {ex.Message}");
            //}
            //===============================================================================
            //using (var context = new AppDbContext())
            //{
            //    Console.WriteLine("Inserting product data...");
            //    var product1 = new Product
            //    {
            //        ProductId = 101,
            //        Name = "Laptop",
            //        Price = 1200.50m
            //    };
            //    var product2 = new Product
            //    {
            //        ProductId = 102,
            //        Name = "Smartphone",
            //        Price = 800.75m
            //    };
            //    context.Products.Add(product1);
            //    context.Products.Add(product2);
            //    context.SaveChanges();
            //    Console.WriteLine("Product entries added successfully!");
            //    Console.WriteLine("\nFetching product data...");
            //    var products = context.Products.ToList();
            //    foreach (var product in products)
            //    {
            //        Console.WriteLine($"\tProduct ID: {product.ProductId}, Name: {product.Name}, Price: {product.Price}");
            //    }
            //}
            //================================================================
            using (var context = new AppDbContext())
            {
                Console.WriteLine("Inserting order data...");
                var order1 = new Order
                {
                    OrderId = 1001,
                    OrderDate = DateTime.Now
                };
                var order2 = new Order
                {
                    OrderId = 1002,
                    OrderDate = DateTime.Now.AddHours(1)
                };
                context.Orders.Add(order1);
                context.Orders.Add(order2);
                context.SaveChanges();
                Console.WriteLine("Order entries added successfully!");
                Console.WriteLine("\nFetching order data...");
                var orders = context.Orders.ToList();
                foreach (var order in orders)
                {
                    Console.WriteLine($"\tOrder ID: {order.OrderId}, Order Number: {order.OrderNumber}, Date: {order.OrderDate}");
                }
            }

        }
    }
}
