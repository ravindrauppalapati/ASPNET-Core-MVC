﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimaryKey_IdentityUsingFluentValidatiom.Models
{
    internal class Order
    {
        public int OrderId { get; set; } //Primary Key
        public int OrderNumber { get; set; } // Identity column
        public DateTime OrderDate { get; set; }
    }
}
