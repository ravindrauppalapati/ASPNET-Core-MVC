﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimaryKey_IdentityUsingFluentValidatiom.Models
{
    internal class Log
    {
        public string LogMessage { get; set; }
        public DateTime LogDate { get; set; }
    }
}
