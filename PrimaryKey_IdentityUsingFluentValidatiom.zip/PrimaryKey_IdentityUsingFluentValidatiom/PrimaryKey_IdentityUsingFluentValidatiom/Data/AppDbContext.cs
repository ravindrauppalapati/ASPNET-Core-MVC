﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PrimaryKey_IdentityUsingFluentValidatiom.Models;

namespace PrimaryKey_IdentityUsingFluentValidatiom.Data
{
    internal class AppDbContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=.\MSSQLSERVER1;Initial Catalog=Primary_IdentityDB;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {  modelBuilder.Entity<Log>()
                .HasNoKey()
            .ToTable("Logs");

            modelBuilder.Entity<Product>()
                .Property(p => p.ProductId)
                .ValueGeneratedNever(); // Disable auto-generation

            modelBuilder.Entity<Order>()
               .Property(p => p.OrderId)
               .ValueGeneratedNever(); // Disable auto-generation

            modelBuilder.Entity<Order>()
                .Property(o => o.OrderNumber)
                .ValueGeneratedOnAdd(); // Make OrderNumber an identity column
        }

        public DbSet<Order> Orders { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Log> Logs { get; set; }
    }
}
