using ExportToExcel.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ExportToExcel.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;

        public HomeController(ILogger<HomeController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ExportToExcel()
        {
            var employees = _context.Employees.ToList();
            ExcelFileHandling fileHandling = new ExcelFileHandling();
            var stream = fileHandling.CreateExcelFile(employees);

            string Name = $"Employee.xlsx";
            return File(stream,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",Name);
        }

        [HttpPost]
        public async Task<IActionResult> ImportExceltoDB(IFormFile file)
        {
            ExcelFileHandling excelFileHandling = new ExcelFileHandling();
            var employees = excelFileHandling.importExcel(file.OpenReadStream());

            await _context.Employees.AddRangeAsync(employees);
            await _context.SaveChangesAsync();

            return View("UploadSuccess");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
