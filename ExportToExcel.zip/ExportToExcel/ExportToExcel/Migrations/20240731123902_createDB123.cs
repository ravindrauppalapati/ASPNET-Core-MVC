﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ExportToExcel.Migrations
{
    /// <inheritdoc />
    public partial class createDB123 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Departmet",
                table: "Employees",
                newName: "Department");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Department",
                table: "Employees",
                newName: "Departmet");
        }
    }
}
