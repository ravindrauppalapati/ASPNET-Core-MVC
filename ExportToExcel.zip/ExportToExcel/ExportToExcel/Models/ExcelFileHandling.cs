﻿using ClosedXML.Excel;

namespace ExportToExcel.Models
{
    public class ExcelFileHandling
    {
        public MemoryStream CreateExcelFile(List<Employee> employee)
        {
            var workBook = new XLWorkbook();
            IXLWorksheet worksheet = workBook.Worksheets.Add("Employees");
          
            worksheet.Cell(1, 1).Value = "ID";
            worksheet.Cell(1, 2).Value = "Name";
            worksheet.Cell(1, 3).Value = "Department";
            worksheet.Cell(1, 4).Value = "Salary";
            worksheet.Cell(1, 5).Value = "Position";
            worksheet.Cell(1, 6).Value = "DateOfJoining";

            int row = 2;

            foreach (var emp in employee)
            {
                worksheet.Cell(row, 1).Value = emp.Id;
                worksheet.Cell(row, 2).Value = emp.Name;
                worksheet.Cell(row, 3).Value = emp.Department;
                worksheet.Cell(row, 4).Value = emp.Salary;
                worksheet.Cell(row, 5).Value = emp.Position;
                worksheet.Cell(row, 6).Value = emp.DateOfJoining;

                row++;
            }

            var stream = new MemoryStream();
            workBook.SaveAs(stream);
            stream.Position = 0;

            return stream;

        }

        public List<Employee> importExcel(Stream stream)
        {
            var employees= new List<Employee>();
            using (var workbook = new XLWorkbook(stream))
            {
                var worksheet = workbook.Worksheet(1);

                var rows = worksheet.RangeUsed().RowsUsed().Skip(1);
                foreach (var row in rows)
                {
                    var employee = new Employee
                    {
                        Name=row.Cell(2).GetValue<string>(),
                        Department=row.Cell(3).GetValue<string>(),
                        Salary= row.Cell(4).GetValue<long>(),
                        Position= row.Cell(5).GetValue<string>(),
                        DateOfJoining= row.Cell(6).GetValue<DateTime>()
                    };

                    employees.Add(employee);
                }
            }

            return employees;
        }
    }
}
