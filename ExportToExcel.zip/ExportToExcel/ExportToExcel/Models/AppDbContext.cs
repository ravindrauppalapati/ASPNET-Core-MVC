﻿using Microsoft.EntityFrameworkCore;

namespace ExportToExcel.Models
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options):base(options)
        {
            
        }

        public DbSet<FileModel> Files { get; set; }
        public DbSet<Employee> Employees { get; set; }
    }
}
