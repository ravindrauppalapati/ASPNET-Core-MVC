﻿using Microsoft.AspNetCore.Mvc;
using PRGPAttern.Models;

namespace PRGPAttern.Controllers
{
    public class FeedBackController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Feedback feedback)
        {
            if (ModelState.IsValid)
            { 
                TempData["SuccessMessage"] = "Thank you for your feedback!";
                return RedirectToAction("Confirmation");
            }
            
            return View(feedback);
        }
        [HttpGet]
        public IActionResult Confirmation()
        {
            return View();
        }
    }
}
