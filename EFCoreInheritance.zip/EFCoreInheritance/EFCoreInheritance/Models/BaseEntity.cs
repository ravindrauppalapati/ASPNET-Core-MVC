﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreInheritance.Models
{
   // [Table("BaseEntity")]
    public class BaseEntity
    { 
        public int Id { get; set; }
        public string CommonProperty { get; set; }
    }

  //  [Table("DerivedTable1")]
    public class DerivedEntityA: BaseEntity
    {
        public string PropertyA { get; set; }
    }
   // [Table("DerivedTable2")]
    public class DerivedEntityB : BaseEntity
    {
        public string PropertyB { get; set; }
    }
}
