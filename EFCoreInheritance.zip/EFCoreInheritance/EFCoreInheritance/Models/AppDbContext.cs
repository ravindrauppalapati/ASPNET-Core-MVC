﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreInheritance.Models
{
    public class AppDbContext:DbContext
    {
        //public AppDbContext(DbContextOptions<AppDbContext> opts) : base(opts) { }
        public AppDbContext() : base()
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        { 
            optionsBuilder.UseSqlServer(@"Data Source=.\MSSQLSERVER1;Initial Catalog=EFCoreDB;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {  // TPH
           //modelBuilder.Entity<BaseEntity>().ToTable("Entities")
           //     .HasDiscriminator<string>("entity_Type")
           //     .HasValue<DerivedEntityA>("EntityA")
           //     .HasValue<DerivedEntityB>("EntityB");

            //TPT
            //modelBuilder.Entity<DerivedEntityA>().HasBaseType<BaseEntity>();
            //modelBuilder.Entity<DerivedEntityB>().HasBaseType<BaseEntity>();

            //TPC
            modelBuilder.Entity<BaseEntity>().UseTpcMappingStrategy();
            modelBuilder.Entity<DerivedEntityA>().ToTable("DerivedTable1");
            modelBuilder.Entity<DerivedEntityB>().ToTable("DerivedTable2");
        }

        public DbSet<BaseEntity> BaseEntities { get; set; }
    }
}
