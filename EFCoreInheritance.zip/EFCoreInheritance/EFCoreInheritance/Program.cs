﻿using EFCoreInheritance.Models;

namespace EFCoreInheritance
{
    internal class Program
    {
        static  void Main(string[] args)
        {
            try
            {

                using (var context = new AppDbContext())
                {
                    var DerivedA = new DerivedEntityA { PropertyA = "ValueA", CommonProperty = "CommonA" };
                    var DerivedB = new DerivedEntityB { PropertyB = "ValueB", CommonProperty = "CommonB" };

                    context.BaseEntities.AddRange(DerivedA,DerivedB);
                    context.SaveChanges();
                    Console.WriteLine("Entities are Added"); 
                }

                using (var context = new AppDbContext())
                {
                    var baseEntity = context.BaseEntities.ToList();
                    foreach (var entity in baseEntity)
                    {
                        if (entity is DerivedEntityA derivedA)
                        {
                            Console.WriteLine($"\t DerivedEntityA : Id :{derivedA.Id} ,PropertyA :{derivedA.PropertyA},commonProperty : {derivedA.CommonProperty}");
                        }

                       else if (entity is DerivedEntityB derivedB)
                        {
                            Console.WriteLine($"\t DerivedEntityB : Id :{derivedB.Id} ,PropertyB :{derivedB.PropertyB},commonProperty : {derivedB.CommonProperty}");

                        }
                    }
                }

                Console.ReadLine();

            }
            catch (Exception ex) {
            Console.WriteLine(ex.Message );
            }

        }
    }
}
