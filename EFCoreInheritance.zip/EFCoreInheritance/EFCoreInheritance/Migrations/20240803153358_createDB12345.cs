﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EFCoreInheritance.Migrations
{
    /// <inheritdoc />
    public partial class createDB12345 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DerivedTable1_BaseEntity_Id",
                table: "DerivedTable1");

            migrationBuilder.DropForeignKey(
                name: "FK_DerivedTable2_BaseEntity_Id",
                table: "DerivedTable2");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BaseEntity",
                table: "BaseEntity");

            migrationBuilder.RenameTable(
                name: "BaseEntity",
                newName: "BaseEntities");

            migrationBuilder.CreateSequence(
                name: "BaseEntitySequence");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "DerivedTable2",
                type: "int",
                nullable: false,
                defaultValueSql: "NEXT VALUE FOR [BaseEntitySequence]",
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "CommonProperty",
                table: "DerivedTable2",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "DerivedTable1",
                type: "int",
                nullable: false,
                defaultValueSql: "NEXT VALUE FOR [BaseEntitySequence]",
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "CommonProperty",
                table: "DerivedTable1",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "BaseEntities",
                type: "int",
                nullable: false,
                defaultValueSql: "NEXT VALUE FOR [BaseEntitySequence]",
                oldClrType: typeof(int),
                oldType: "int")
                .OldAnnotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_BaseEntities",
                table: "BaseEntities",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_BaseEntities",
                table: "BaseEntities");

            migrationBuilder.DropColumn(
                name: "CommonProperty",
                table: "DerivedTable2");

            migrationBuilder.DropColumn(
                name: "CommonProperty",
                table: "DerivedTable1");

            migrationBuilder.DropSequence(
                name: "BaseEntitySequence");

            migrationBuilder.RenameTable(
                name: "BaseEntities",
                newName: "BaseEntity");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "DerivedTable2",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValueSql: "NEXT VALUE FOR [BaseEntitySequence]");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "DerivedTable1",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValueSql: "NEXT VALUE FOR [BaseEntitySequence]");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "BaseEntity",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValueSql: "NEXT VALUE FOR [BaseEntitySequence]")
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_BaseEntity",
                table: "BaseEntity",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_DerivedTable1_BaseEntity_Id",
                table: "DerivedTable1",
                column: "Id",
                principalTable: "BaseEntity",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_DerivedTable2_BaseEntity_Id",
                table: "DerivedTable2",
                column: "Id",
                principalTable: "BaseEntity",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
