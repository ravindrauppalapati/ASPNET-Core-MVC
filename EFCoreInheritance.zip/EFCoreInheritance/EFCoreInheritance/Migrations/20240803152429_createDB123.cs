﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EFCoreInheritance.Migrations
{
    /// <inheritdoc />
    public partial class createDB123 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Entities",
                table: "Entities");

            migrationBuilder.DropColumn(
                name: "PropertyA",
                table: "Entities");

            migrationBuilder.DropColumn(
                name: "PropertyB",
                table: "Entities");

            migrationBuilder.DropColumn(
                name: "entity_Type",
                table: "Entities");

            migrationBuilder.RenameTable(
                name: "Entities",
                newName: "BaseEntity");

            migrationBuilder.AddPrimaryKey(
                name: "PK_BaseEntity",
                table: "BaseEntity",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "DerivedTable1",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false),
                    PropertyA = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DerivedTable1", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DerivedTable1_BaseEntity_Id",
                        column: x => x.Id,
                        principalTable: "BaseEntity",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DerivedTable2",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false),
                    PropertyB = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DerivedTable2", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DerivedTable2_BaseEntity_Id",
                        column: x => x.Id,
                        principalTable: "BaseEntity",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DerivedTable1");

            migrationBuilder.DropTable(
                name: "DerivedTable2");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BaseEntity",
                table: "BaseEntity");

            migrationBuilder.RenameTable(
                name: "BaseEntity",
                newName: "Entities");

            migrationBuilder.AddColumn<string>(
                name: "PropertyA",
                table: "Entities",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PropertyB",
                table: "Entities",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "entity_Type",
                table: "Entities",
                type: "nvarchar(13)",
                maxLength: 13,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Entities",
                table: "Entities",
                column: "Id");
        }
    }
}
