﻿using CascadingDropDownApp.Models;
using Microsoft.EntityFrameworkCore;

namespace CascadingDropDownApp.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> opts): base (opts)
        {
            
        }
        public DbSet<Country> Countries { get; set; }
        public DbSet<State> States { get; set; }
        public DbSet<City> Cities { get; set; }
    }
}
